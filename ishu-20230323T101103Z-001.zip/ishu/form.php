<html>
<head>
        <title>sing up</title>
</head>
<body>
      <form method="POST" action="">
        <table border="3" align="center" action="insert.php">
            <tr>
                <td>
                    sing up
</td>
</tr>
    <tr>
        <td>
        First name:-
        </td>
        <td>
                <input type="text" name="fnm" placeholder="enter first name">
        </td>
    </tr>
    <tr>
        <td>

        Last name:-
        </td>
        <td>
        <input type="text" name="lnm" placeholder="enter last name">
        </td>
    </tr>
    <tr>
        <td>
            E-mail:-
        </td>
        <td>
        <input type="email" name="email" placeholder="enter  email address" >
        </td>
    </tr>
        <tr>
            <td>
        password:-
            </td>
            <td>

        <input type="password" name="psw" placeholder="enter password">
            </td>
        </tr>
        <tr>
            <td>
        contact:-
            </td>
            <td>
        <input type="contact" name="contact" >
            </td>
        </tr>
        <tr>
            <td>
        course:
            </td>
        <td>
        <select name="course">
            <option value="BCA">
                BCA
            </option>
            <option value="MCA">
                MCA
            </option>
            <option value="BBA">
                BBA
            </option>
            <option value="BSCIT">
                BSCIT
            </option>
            <option value="LLB">
                LLB
            </option>
            <option value="B.ED">
                B.ED
            </option>
        </select>
    </td>
</tr>
<tr>
    <td>
             city:
</td>
<td>
    
                <select name="city">
                    <option value="rajkot">
                        rajkot
                    </option>
                    <option value="jamngar">
                        jamngar
                    </option>
            
                    <option value="surat">
                        surat
                    </option>
            
                    <option value="ahemdabad">
                        ahemdabad
                    </option>
                </select>
            </td>
        </tr>
        <tr>
            <td><input type="submit" name="sbt" value="login">
            </td>
        </tr>
    </table>
</form>
</body>
</html>

            

