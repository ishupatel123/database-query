
<form action="login_CHK.php" method="post">
	
	<input type="email" name="e" value=""  placeholder="Enter E-mail Address">
	<br>
	<input type="password" name="psd" value=""  placeholder="Enter Password">
	<br>
	<input type="submit" value="Submit" name="sbt">
	<a href="form.php">Signup</a>
</form>